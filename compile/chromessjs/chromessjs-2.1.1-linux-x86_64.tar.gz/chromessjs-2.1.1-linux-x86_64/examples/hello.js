"use strict";
console.log('Hello, world!');
chromess.exit();
