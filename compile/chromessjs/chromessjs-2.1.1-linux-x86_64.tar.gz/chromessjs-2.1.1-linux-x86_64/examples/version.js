"use strict";
console.log('using chromessJS version ' +
  chromess.version.major + '.' +
  chromess.version.minor + '.' +
  chromess.version.patch);
chromess.exit();
